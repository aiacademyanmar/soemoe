package asia.aaii.sukhapanya;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.text.*;
import java.io.*;
import java.util.*;

/** Image-backed, high-fidelity recreation of the 14 approved UI design screens.
 * Native hit targets and dialogs provide accessible, functional interactions.
 * 3D and certificate imagery remain illustrative, never clinical/credential output.
 */
public final class MainActivity extends Activity {
  private static final int GREEN=0xff105d44, DARK=0xff14392b, CREAM=0xfff8faf5;
  private static final int SCREEN_COUNT=14;
  private static final String[] TITLES={"Splash","Home","Plant Atlas","Plant Detail","Botanical Study","Lessons","Comic Learning","Quiz","World Research","Herbal Safety","Symptom Education","Certificate","Profile","Settings"};
  private static final String[] PLANTS={
    "ရှားစောင်းလက်ပပ်|Aloe vera", "တမာ|Azadirachta indica", "ဆေးခါးကြီး|Andrographis paniculata", "နနွင်း|Curcuma longa", "ချင်း|Zingiber officinale", "ကြက်သွန်နီ|Allium cepa",
    "ကင်မွန်းချဉ်|Acacia concinna","မရိုးကြီး|Adhatoda vasica","ပဒဲကောကြီး|Alpinia galanga","နာနတ်|Ananas sativus","ဩဇာ|Annona squamosa","ကွမ်းသီး|Areca catechu",
    "စောင်းလျား|Averrhoa carambola","လိပ်ဆူးရွှေ|Barleria prionitis","ကင်ပွန်းနီ|Basella rubra","ဖုတ်မသိမ်း|Blumea balsamifera","ထန်း|Borassus flabellifer","သဘော်မညှိုး|Catharanthus roseus",
    "သင်္ဘောမဲဇလီ|Cassia alata","ငု|Cassia fistula","နလင်ကျော်|Cinnamomum obtusifolium","ငါးရံ့ပတူ|Clerodendron siphonanthus","အုန်း|Cocos nucifera","ဇီရာရွက်ထူ|Coleus aromaticus",
    "ကဒက်|Crataeva religiosa","ကိုရံကြီး|Crinum asiaticum","မြေစာမြက်|Cynodon dactylon","ဂွေးတောက်|Dregea volubilis","ကြိတ်မှန်|Eclipta alba","ကျွဲကျောင်းမင်ဆေး|Euphorbia hirta",
    "ရှားစောင်းသင်္ကနက်|Euphorbia splendens","ရင်ခတ်ကြီး|Gardenia coronaria","မညှိုးလုံး|Gomphrena globosa"};
  private static final String[] LESSONS={
    "တိုင်းရင်းဆေးပညာ အခြေခံ", "ဆေးပင်မျိုးစိတ် ခွဲခြားခြင်း", "ဆေးကျမ်းနှင့် အချက်အလက်ရင်းမြစ်", "တိုင်းရင်းအသုံးနှင့် သိပ္ပံသက်သေ", "ဆေးပင်အစိတ်အပိုင်းများ", "ဘေးကင်းရေးစစ်ဆေးခြင်း",
    "ဆေးနှင့်အပင် အပြန်အလှန်သက်ရောက်မှု", "အရည်အသွေးထိန်းချုပ်ခြင်း", "WHO လမ်းညွှန်ချက်", "NCCIH Safety", "AI Evidence Review", "သုတေသနကျင့်ဝတ်"};
  private int current=1, previous=1, plantIndex=0, lessonIndex=0, score=0, answered=0, comicScene=0, chosen=-1;
  private boolean favorite=false, dark=false;
  private FrameLayout screenFrame;
  private Bitmap bitmap;
  private final ArrayList<Hot> taps=new ArrayList<>();
  private static class Hot { int x1,y1,x2,y2; String name; Runnable action;
    Hot(int a,int b,int c,int d,String n,Runnable r){x1=a;y1=b;x2=c;y2=d;name=n;action=r;}}

  @Override public void onCreate(Bundle state){super.onCreate(state);hideBars();score=getPreferences(MODE_PRIVATE).getInt("score",0);answered=getPreferences(MODE_PRIVATE).getInt("answered",0);favorite=getPreferences(MODE_PRIVATE).getBoolean("fave",false); dark=getPreferences(MODE_PRIVATE).getBoolean("dark",false);show(1);}
  private void hideBars(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
  private void show(int n){if(n<1||n>SCREEN_COUNT)return; if(current!=n)previous=current;current=n;
    if(bitmap!=null){bitmap.recycle();bitmap=null;}
    try(InputStream in=getAssets().open(String.format(java.util.Locale.US,"screen_%02d.webp",current))){bitmap=BitmapFactory.decodeStream(in);}catch(Exception e){new AlertDialog.Builder(this).setMessage("Asset error: "+e.getMessage()).setPositiveButton("OK",null).show();return;}
    taps.clear();screenFrame=new FrameLayout(this);screenFrame.setBackgroundColor(CREAM);
    ImageView image=new ImageView(this);image.setScaleType(ImageView.ScaleType.FIT_XY);image.setImageBitmap(bitmap);
    screenFrame.addView(image,new FrameLayout.LayoutParams(-1,-1));setContentView(screenFrame);
    configureTouches();screenFrame.post(this::putTapTargets);hideBars();}
  private void tap(int x1,int y1,int x2,int y2,String label,Runnable action){taps.add(new Hot(x1,y1,x2,y2,label,action));}
  private void putTapTargets(){int w=screenFrame.getWidth(),h=screenFrame.getHeight();for(Hot t:taps){View v=new View(this);v.setContentDescription(t.name);v.setFocusable(true);v.setClickable(true);
    FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.max(1,(t.x2-t.x1)*w/1080),Math.max(1,(t.y2-t.y1)*h/1920));lp.leftMargin=t.x1*w/1080;lp.topMargin=t.y1*h/1920;
    v.setOnClickListener(z->t.action.run());screenFrame.addView(v,lp);}}
  private void common(){if(current!=1){tap(0,82,155,222,"Back",()->show(previous==current?2:previous));tap(815,82,925,205,"Search",this::search);tap(927,85,1080,205,"More",this::menu);}
    if(current>1&&current!=12){tap(0,1750,215,1920,"Home",()->show(2));tap(215,1750,430,1920,"Plant Atlas",()->show(3));tap(430,1750,648,1920,"Lessons",()->show(6));tap(648,1750,860,1920,"Research",()->show(9));tap(860,1750,1080,1920,"Profile",()->show(13));}}
  private void configureTouches(){common();switch(current){
    case 1: tap(150,1510,940,1890,"Start Sukha Panya",()->show(2));break;
    case 2: homeZones();break;
    case 3: plantZones();break;
    case 4: detailZones();break;
    case 5: studyZones();break;
    case 6: lessonZones();break;
    case 7: comicZones();break;
    case 8: quizZones();break;
    case 9: researchZones();break;
    case 10: safetyZones();break;
    case 11: symptomZones();break;
    case 12: certificateZones();break;
    case 13: profileZones();break;
    case 14: settingsZones();break;
  }}
  private void homeZones(){tap(60,350,1020,535,"Search plant or course",this::search);tap(50,605,1010,930,"Featured lesson",()->openLesson(0));
    tap(40,1040,340,1330,"Medicinal Plants",()->show(3));tap(345,1040,685,1330,"Learning",()->show(6));tap(690,1040,1050,1330,"Research",()->show(9));
    tap(45,1320,340,1550,"Safety",()->show(10));tap(345,1320,685,1550,"Botanical Study",()->show(5));tap(690,1320,1050,1550,"Certificate",()->show(12));tap(750,955,1050,1040,"See all",()->show(6));}
  private void plantZones(){tap(40,330,1045,520,"Search plants",this::searchPlants);tap(55,520,1020,640,"Filter plants",this::plantChooser);
    for(int i=0;i<4;i++){final int id=i;tap(45,660+i*230,1020,865+i*230,"Plant "+(i+1),()->choosePlant(id));}
    tap(750,230,1065,345,"All 33 plants",this::plantChooser);}
  private void detailZones(){tap(780,210,1020,400,"Bookmark plant",()->{favorite=!favorite;getPreferences(MODE_PRIVATE).edit().putBoolean("fave",favorite).apply();toast(favorite?"Bookmark သိမ်းပြီးပါပြီ":"Bookmark ဖယ်ရှားပြီးပါပြီ");});
    tap(45,270,1000,750,"Botanical study",()->show(5));tap(50,975,400,1100,"Botanical identity",()->plantDetails(plantIndex));
    tap(400,975,690,1100,"Evidence",()->evidence());tap(690,975,1040,1100,"Safety",()->show(10));tap(60,1130,1020,1710,"Plant source",()->openDrive());}
  private void studyZones(){tap(100,350,960,1180,"Plant parts",()->sheet("Botanical Study","ဒီပုံမှာ ရွက်၊ အမြစ်နှင့် ပင်စည်တို့ကို ပုံမှန်လေ့လာနိုင်ရန် သရုပ်ဖော်ထားပါသည်။ အပင်အစစ်၏ 3D Scan/AR Model မဟုတ်ပါ။",new String[]{"အရွက်","အမြစ်","ပင်စည်"}, i->toast(new String[]{"အရွက်","အမြစ်","ပင်စည်"}[i]+" ကိုရွေးထားပါသည်။")));
    tap(50,1200,500,1385,"Plant details",()->show(4));tap(520,1200,1040,1385,"Plant list",()->show(3));}
  private void lessonZones(){tap(35,350,1035,580,"Featured lesson",()->openLesson(0));for(int i=0;i<5;i++){final int j=i;tap(40,600+i*190,1040,790+i*190,"Lesson "+(j+1),()->openLesson(j));}tap(700,210,1070,340,"All lessons",this::lessonChooser);}
  private void comicZones(){tap(50,345,1020,1220,"Comic scene",()->comicDialog());tap(50,1250,500,1560,"Previous scene",()->{comicScene=(comicScene+2)%3;comicDialog();});tap(520,1250,1050,1600,"Next scene",()->{comicScene=(comicScene+1)%3;comicDialog();});}
  private void quizZones(){for(int i=0;i<4;i++){final int j=i;tap(60,790+i*175,1030,960+i*175,"Answer "+(char)('A'+i),()->selectAnswer(j));}tap(50,1560,1030,1745,"Check answer",()->{if(chosen<0){quizDialog();}else{showAnswer(chosen);}});tap(400,200,1000,360,"Quiz progress",this::quizDialog);}
  private void researchZones(){tap(50,295,1030,435,"Search research",this::researchChooser);for(int i=0;i<3;i++){final int k=i;tap(50,570+i*260,1030,820+i*260,"Research source",()->openResearch(k));}tap(40,440,1015,560,"Research categories",this::researchChooser);}
  private void safetyZones(){tap(45,315,1035,650,"Critical warnings",()->sheet("ဘေးကင်းရေး","ဆေးဖက်ဝင်အပင်သည် ဆေးဝါးများ၊ ကိုယ်ဝန်ဆောင်ခြင်းနှင့် နာတာရှည်ရောဂါများနှင့် ဆက်စပ်နိုင်သည်။ သုတေသနတစ်ခုတည်းကို ဆေးညွှန်းအဖြစ် မသုံးပါနှင့်။",null,null));
    for(int i=0;i<4;i++)tap(50,650+i*220,1030,850+i*220,"Safety details",this::safetyAlert);tap(55,1500,1040,1750,"Emergency guidance",()->show(11));}
  private void symptomZones(){for(int i=0;i<8;i++){final int j=i;tap(40+(i%2)*520,430+(i/2)*285,520+(i%2)*520,675+(i/2)*285,"Symptom education",()->symptomDialog(j));}tap(45,1570,1050,1740,"Urgent warning",this::safetyAlert);}
  private void certificateZones(){tap(180,380,900,1540,"Certificate preview",()->sheet("Certificate of Completion","ဤပုံသည် နမူနာသင်ယူပြီးမြောက်မှု လက်မှတ်သာဖြစ်သည်။ ဆရာဝန်လိုင်စင် သို့မဟုတ် အတည်ပြုအသိအမှတ်ပြုလက်မှတ် မဟုတ်ပါ။",null,null));tap(40,1580,1040,1900,"Learning record",this::progress);}
  private void profileZones(){tap(60,320,1030,570,"Learning progress",this::progress);tap(40,610,1010,1320,"Learning record",this::progress);tap(50,1310,1040,1500,"Bookmarks",()->sheet("Saved Plants",favorite?"Aloe vera ကို Bookmark သိမ်းထားသည်။":"Bookmark မရှိသေးပါ။",null,null));tap(40,1530,1040,1740,"Settings",()->show(14));}
  private void settingsZones(){tap(35,310,1040,500,"Language",()->sheet("Language","အက်ပ်အဓိကဘာသာစကားမှာ မြန်မာဘာသာဖြစ်ပါသည်။",null,null));tap(40,530,1040,720,"Theme",()->{dark=!dark;getPreferences(MODE_PRIVATE).edit().putBoolean("dark",dark).apply();toast("Dark mode setting: "+(dark?"ON":"OFF")+" (Visual theme follows reference designs)");});tap(40,750,1040,985,"Offline",()->sheet("Offline Library","Screen Design နဲ့ လေ့လာရေးဒေတာများကို APK ထဲ ထည့်ထားပြီး Offline ဖွင့်နိုင်သည်။ External References ကိုဖတ်ရန် Internet လိုအပ်သည်။",null,null));tap(40,1000,1040,1550,"Privacy and Data",this::privacy);tap(40,1570,1040,1765,"About",()->sheet("Sukha Panya 8.2","Myanmar Traditional Medicine • 14 Design-matched Native Screens\nပညာရေးနှင့် သုတေသနအတွက်သာ။",null,null));}

  private void selectAnswer(int idx){chosen=idx;toast("အဖြေ "+(char)('A'+idx)+" ရွေးထားသည် — Submit ကိုနှိပ်ပါ");}
  private void showAnswer(int idx){boolean ok=idx==1;answered++;if(ok)score++;getPreferences(MODE_PRIVATE).edit().putInt("answered",answered).putInt("score",score).apply();new AlertDialog.Builder(this).setTitle(ok?"✅ မှန်ကန်ပါသည်":"သင်ခန်းစာပြန်လေ့လာပါ").setMessage("ရိုးရာဆေးကျမ်းမှာ ဖော်ပြခြင်းနဲ့ သိပ္ပံနည်းကျ ထိရောက်မှုသက်သေရှိခြင်းဟာ မတူပါ။\nသင်ဖြေဆိုထားမှု: "+answered+" | မှန်: "+score).setPositiveButton("နောက်တစ်ပုဒ်",(d,w)->{chosen=-1;quizDialog();}).setNegativeButton("အပြီးသတ်",(d,w)->show(6)).show();}
  private void quizDialog(){final int[] pos={0};String[] qs={
    "ဆေးပင်အမည်တစ်ခုကို အတည်ပြုရာတွင် အရေးကြီးသည့်အချက်က ဘာလဲ။",
    "ရိုးရာအသုံးပြုမှု တစ်ခုတည်းက ကုသမှုထိရောက်ကြောင်း သက်သေလား။",
    "ဆေးဖက်ဝင်အပင် သုံးစွဲမီ အရေးကြီးသောအချက်က ဘာလဲ။"};
    String[][] opts={{"အရောင်သာကြည့်ရန်","သိပ္ပံအမည်နှင့် ရင်းမြစ်စစ်ရန်","အမည်တိုတစ်ခုကို ယုံကြည်ရန်"},{"ဟုတ်သည်","မဟုတ်ပါ — သုတေသနလိုအပ်သည်","အားလုံးအတွက် အတူတူ"},{"ကုသမှုတစ်ခုလုံး အစားထိုးရန်","ပမာဏအလိုလိုရွေးရန်","ဘေးကင်းရေးနှင့် ဆေးဓာတ်ပြန်လှန်မှုစစ်ရန်"}};
    int[] correct={1,1,2};runQuiz(pos,qs,opts,correct);}
  private void runQuiz(int[] pos,String[] qs,String[][] opts,int[] correct){int q=pos[0];if(q>=qs.length){new AlertDialog.Builder(this).setTitle("Quiz ပြီးပါပြီ").setMessage("Overall progress: "+score+" / "+answered+"\nသင်ယူမှုအတွက်သာ၊ ဆေးဘက်ဆိုင်ရာလက်မှတ်မဟုတ်ပါ။").setPositiveButton("မှတ်တမ်းကြည့်ရန်",(d,w)->progress()).setNegativeButton("ပိတ်ရန်",null).show();return;}
    new AlertDialog.Builder(this).setTitle("Quiz "+(q+1)+" / "+qs.length).setMessage(qs[q]).setSingleChoiceItems(opts[q],-1,(d,n)->{d.dismiss();boolean ok=n==correct[q];answered++;if(ok)score++;getPreferences(MODE_PRIVATE).edit().putInt("answered",answered).putInt("score",score).apply();new AlertDialog.Builder(this).setTitle(ok?"✅ မှန်ကန်ပါသည်":"❗ ပြန်လေ့လာပါ").setMessage("အဖြေမှန်: "+opts[q][correct[q]]+"\nဤ Quiz သည် သင်ယူမှုအတွက်ဖြစ်ပါသည်။").setPositiveButton("ရှေ့ဆက်",(dd,ww)->{pos[0]++;runQuiz(pos,qs,opts,correct);}).show();}).setNegativeButton("ပိတ်ရန်",null).show();}
  private void search(){sheet("ရှာဖွေရန်","အမျိုးအစားရွေးပါ",new String[]{"ဆေးဖက်ဝင်အပင်","သင်ခန်းစာ","သုတေသန"},n->{if(n==0)searchPlants();else if(n==1)lessonChooser();else researchChooser();});}
  private void searchPlants(){EditText input=new EditText(this);input.setSingleLine(true);input.setHint("မြန်မာ/Latin အမည်...");new AlertDialog.Builder(this).setTitle("ဆေးဖက်ဝင်အပင် ရှာဖွေရန်").setView(input).setPositiveButton("Search",(d,w)->{String q=input.getText().toString().trim().toLowerCase(Locale.ROOT);ArrayList<String> found=new ArrayList<>();ArrayList<Integer> ids=new ArrayList<>();for(int i=0;i<PLANTS.length;i++)if(q.isEmpty()||PLANTS[i].toLowerCase(Locale.ROOT).contains(q)){found.add(PLANTS[i].replace("|"," • "));ids.add(i);}if(found.isEmpty()){toast("မတွေ့ပါ။ Scientific Name ကိုထပ်ရှာပါ။");return;}new AlertDialog.Builder(this).setTitle("တွေ့ရှိမှု "+found.size()+" ခု").setItems(found.toArray(new String[0]),(x,idx)->choosePlant(ids.get(idx))).setNegativeButton("ပိတ်ရန်",null).show();}).setNegativeButton("ပိတ်ရန်",null).show();}
  private void plantChooser(){String[] n=new String[PLANTS.length];for(int i=0;i<n.length;i++)n[i]=PLANTS[i].replace("|"," • ");new AlertDialog.Builder(this).setTitle("ဆေးပင် ၃၃ မျိုး • A-Z").setItems(n,(d,i)->choosePlant(i)).setNegativeButton("ပိတ်ရန်",null).show();}
  private void choosePlant(int i){plantIndex=i;if(i==0)show(4);else plantDetails(i);}
  private void plantDetails(int i){String[] p=PLANTS[i].split("\\|");new AlertDialog.Builder(this).setTitle(p[0]).setMessage("Scientific name: "+p[1]+"\n\nကျမ်းညွှန်း: Medicinal Plants of Myanmar\n\nဤအချက်အလက်မှာ အမည်ညွှန်းအတွက်သာဖြစ်ပြီး ပုံ၊ မျိုးစိတ်၊ ကုသမှုအထောက်အထားတို့ကို ကျွမ်းကျင်သူ စစ်ဆေးရန် လိုအပ်သည်။").setPositiveButton("Source Library",(d,w)->openDrive()).setNegativeButton("ပြန်သွားရန်",null).show();}
  private void evidence(){sheet("Evidence & Review","မူရင်းတိုင်းရင်းဆေးကျမ်းတွင် ဖော်ပြထားခြင်းသည် လူနာပေါ် ကုသထိရောက်မှု အတည်ပြုထားခြင်းမဟုတ်ပါ။ Source page နှင့် Clinical Evidence ကို သီးခြားစစ်ဆေးရပါမယ်။",null,null);}
  private void openLesson(int i){lessonIndex=i;new AlertDialog.Builder(this).setTitle("သင်ခန်းစာ "+(i+1)+" • "+LESSONS[i]).setMessage("ယခုသင်ခန်းစာတွင် မူရင်းကျမ်း၊ သိပ္ပံအမည်နှင့် Safety Evidence ကို ခွဲခြားသုံးသပ်ရန် သင်ယူပါမယ်။\n\nမသိရသေးသည့်အချက်များကို မသေချာကြောင်း ဖော်ပြရန်၊ ဆေးညွှန်းကို AI ဖြင့် မထုတ်ရန်။").setPositiveButton("Comic Lesson",(d,w)->show(7)).setNeutralButton("Quiz",(d,w)->{show(8);quizDialog();}).setNegativeButton("ပြီးပြီ",(d,w)->getPreferences(MODE_PRIVATE).edit().putBoolean("lesson_"+i,true).apply()).show();}
  private void lessonChooser(){String[] arr=new String[LESSONS.length];for(int i=0;i<arr.length;i++)arr[i]=(i+1)+". "+LESSONS[i];new AlertDialog.Builder(this).setTitle("သင်ခန်းစာ ၁၂ ခန်း").setItems(arr,(d,n)->openLesson(n)).setNegativeButton("ပိတ်ရန်",null).show();}
  private void comicDialog(){String[] a={"Scene 1: ဆေးပင်ကို ကြည့်ပြီး အမည်နှင့် ပုံစံကို လေ့လာပါ။","Scene 2: ဆရာနှင့်အတူ မူရင်းဆေးကျမ်းကို ရှာဖတ်ပါ။","Scene 3: ရိုးရာသတင်းအချက်အလက်နှင့် ဆေးပညာသုတေသနကို ခွဲခြားပါ။"};final String msg=a[comicScene];new AlertDialog.Builder(this).setTitle("Comic • "+(comicScene+1)+" / 3").setMessage(msg).setPositiveButton("နောက်တစ်ခန်း",(d,w)->{comicScene=(comicScene+1)%3;comicDialog();}).setNeutralButton("Quiz",(d,w)->{show(8);quizDialog();}).setNegativeButton("ပိတ်ရန်",null).show();}
  private void openResearch(int i){String[] sources={"Medicinal Plants of Myanmar (Department of Traditional Medicine)","WHO Traditional, Complementary and Integrative Medicine", "NIH NCCIH — Herbs at a Glance"};String[] urls={"https://drive.google.com/file/d/12bVfs8sZ1d-Mfo2PThF2l0472MvrjJv9/view", "https://www.who.int/initiatives/traditional-complementary-and-integrative-medicine", "https://www.nccih.nih.gov/health/herbs-at-a-glance"};new AlertDialog.Builder(this).setTitle(sources[i]).setMessage("မူရင်းစာမျက်နှာကို Browser မှ ဖတ်ရှုရန်။\n\nသုတေသန အထောက်အထားနှင့် ဘေးကင်းရေးကို ကျွမ်းကျင်သူ ထပ်မံစစ်ဆေးရန် လိုအပ်ပါသည်။").setPositiveButton("Open Source",(d,w)->openLink(urls[i])).setNegativeButton("ပိတ်ရန်",null).show();}
  private void researchChooser(){String[] a={"မြန်မာ့တိုင်းရင်းဆေးကျမ်း","WHO International Guidance","NIH/NCCIH Herbal Safety"};sheet("Research Sources","မူရင်းအချက်အလက်များကို ရင်းမြစ်နှင့်အတူ သီးခြားဖွင့်ဖတ်နိုင်ပါသည်။",a,this::openResearch);}
  private void openDrive(){openLink("https://drive.google.com/file/d/12bVfs8sZ1d-Mfo2PThF2l0472MvrjJv9/view");}
  private void openLink(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ex){toast("Browser မတွေ့ပါ။");}}
  private void safetyAlert(){new AlertDialog.Builder(this).setTitle("⚠ Safety Information").setMessage("အပင်အချို့သည် ဆေးဝါးများနှင့် ပြန်လှန်သက်ရောက်နိုင်ပြီး ကိုယ်ဝန်ဆောင်၊ ကလေးနှင့် နာတာရှည်ရောဂါရှိသူများတွင် အန္တရာယ်ရှိနိုင်သည်။\n\nအသက်ရှူခက်၊ ရင်ဘတ်အောင့်၊ သတိလစ်၊ သွေးထွက်များနေပါက အရေးပေါ် ဆေးဘက်အကူအညီ ရယူပါ။").setPositiveButton("Symptom Education",(d,w)->show(11)).setNegativeButton("ပိတ်ရန်",null).show();}
  private void symptomDialog(int i){String[] names={"အစာအိမ်", "အသက်ရှူ", "အရေပြား", "အဖျား", "ကိုက်ခဲမှု", "နာကျင်မှု", "ရင်ဘတ်", "သတိလစ်ခြင်း"};new AlertDialog.Builder(this).setTitle(names[i]+" ဆိုင်ရာ ပညာပေး").setMessage("ဤအပိုင်းသည် လက္ခဏာသိရှိနားလည်ရန် ပညာပေးခြင်းသာဖြစ်ပြီး ရောဂါရှာဖွေခြင်းမဟုတ်ပါ။ အရေးပေါ်လက္ခဏာရှိပါက ဆေးဘက်အကူအညီ ရယူပါ။").setPositiveButton("Safety",(d,w)->show(10)).setNegativeButton("ပိတ်ရန်",null).show();}
  private void progress(){int count=0;for(int i=0;i<LESSONS.length;i++)if(getPreferences(MODE_PRIVATE).getBoolean("lesson_"+i,false))count++;new AlertDialog.Builder(this).setTitle("သင်ယူမှု မှတ်တမ်း").setMessage("Lessons marked complete: "+count+" / 12\nQuiz Correct: "+score+" / "+answered+"\n\nဆရာဝန်လိုင်စင် မဟုတ်ပါ။ App ထဲမှ Sample Certificate ကို အတည်ပြုလက်မှတ်အဖြစ် မသုံးရပါ။").setPositiveButton("Certificate Preview",(d,w)->show(12)).setNegativeButton("ပိတ်ရန်",null).show();}
  private void privacy(){new AlertDialog.Builder(this).setTitle("Privacy & Local Data").setMessage("သင်ခန်းစာမှတ်တမ်း၊ Quiz ရမှတ်၊ Bookmark တို့ကို ဖုန်းအတွင်းသာ သိမ်းထားပါတယ်။ လူနာကိုယ်ရေးအချက်အလက် မတောင်းပါ။\n\nData ကို ဖျက်နိုင်ပါသည်။").setPositiveButton("Clear Study Data",(d,w)->new AlertDialog.Builder(this).setTitle("Confirm Reset").setMessage("အက်ပ်ထဲက သင်ယူမှုမှတ်တမ်း ဖျက်မလား။").setPositiveButton("ဖျက်ရန်",(dd,ww)->{getPreferences(MODE_PRIVATE).edit().clear().apply();score=0;answered=0;favorite=false;toast("Reset successful");}).setNegativeButton("မဖျက်ပါ",null).show()).setNegativeButton("ပိတ်ရန်",null).show();}
  interface Choose {void accept(int n);}
  private void sheet(String title,String msg,String[] choices,Choose action){AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(title).setMessage(msg);if(choices!=null)b.setItems(choices,(d,n)->{if(action!=null)action.accept(n);});b.setNegativeButton("ပိတ်ရန်",null).show();}
  private void menu(){String[] actions={"Home","Plant Atlas","Lessons","Comic Learning","Quiz","Research","Safety","Symptom Guide","Certificate","Profile","Settings"};int[] dest={2,3,6,7,8,9,10,11,12,13,14};new AlertDialog.Builder(this).setTitle("Sukha Panya • App Menu").setItems(actions,(d,n)->show(dest[n])).setNegativeButton("ပိတ်ရန်",null).show();}
  private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
  @Override public void onBackPressed(){if(current==1||current==2){new AlertDialog.Builder(this).setMessage("App မှ ထွက်မလား။").setPositiveButton("ထွက်ရန်",(d,w)->finish()).setNegativeButton("မထွက်ပါ",null).show();}else show(current==4||current==5?3:2);}
  @Override protected void onDestroy(){super.onDestroy();if(bitmap!=null&&!bitmap.isRecycled())bitmap.recycle();}
}
