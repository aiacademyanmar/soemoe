package asia.aaii.patthana

data class Condition(val id: Int, val mm: String, val pali: String, val meaning: String, val fileName: String) {
    val sourceUrl: String get() = "https://www.abhidhamma.com/" + fileName
}

object Catalog {
    val introductoryUrl = "https://www.abhidhamma.com/Patthana.mp3"
    val sourcePage = "https://www.abhidhamma.com/incl.php?aw=abhidhamma_audios.txt"
    val data = listOf(
        Condition(1, "ဟေတုပစ္စယော", "Hetu paccayo", "အမြစ်အကြောင်းတရားအဖြစ် ကျေးဇူးပြုခြင်း", "01_Hetupaccayo.mp3"),
        Condition(2, "အာရမ္မဏပစ္စယော", "Ārammaṇa paccayo", "အာရုံအဖြစ် ကျေးဇူးပြုခြင်း", "02_Arammanapaccayo.mp3"),
        Condition(3, "အဓိပတိပစ္စယော", "Adhipati paccayo", "အကြီးအမှူးဖြစ်၍ ကျေးဇူးပြုခြင်း", "03_Adhipatipaccayo.mp3"),
        Condition(4, "အနန္တရပစ္စယော", "Anantara paccayo", "အကြားမရှိ ဆက်တိုက်ဖြစ်၍ ကျေးဇူးပြုခြင်း", "04_Anantarapaccayo.mp3"),
        Condition(5, "သမနန္တရပစ္စယော", "Samanantara paccayo", "အခြားမဲ့ အစဉ်အတိုင်း ဆက်စပ်ကျေးဇူးပြုခြင်း", "05_Samanantarapaccayo.mp3"),
        Condition(6, "သဟဇာတပစ္စယော", "Sahajāta paccayo", "အတူတကွ ဖြစ်ပေါ်၍ ကျေးဇူးပြုခြင်း", "06_Sahajatapaccayo.mp3"),
        Condition(7, "အညမညပစ္စယော", "Aññamañña paccayo", "အပြန်အလှန် ကျေးဇူးပြုခြင်း", "07_Annamannapaccayo.mp3"),
        Condition(8, "နိဿယပစ္စယော", "Nissaya paccayo", "မှီခိုရာအဖြစ် ကျေးဇူးပြုခြင်း", "08_Nissayapaccayo.mp3"),
        Condition(9, "ဥပနိဿယပစ္စယော", "Upanissaya paccayo", "အားကြီးသော ထောက်ပံ့မှုဖြင့် ကျေးဇူးပြုခြင်း", "09_Upanissayapaccayo.mp3"),
        Condition(10, "ပုရေဇာတပစ္စယော", "Purejāta paccayo", "ရှေ့ကဖြစ်ပေါ်၍ ကျေးဇူးပြုခြင်း", "10_Purejatapaccayo.mp3"),
        Condition(11, "ပစ္ဆာဇာတပစ္စယော", "Pacchājāta paccayo", "နောက်မှဖြစ်ပေါ်၍ ကျေးဇူးပြုခြင်း", "11_Pacchajatapaccayo.mp3"),
        Condition(12, "အာသေဝနပစ္စယော", "Āsevana paccayo", "ထပ်ခါတလဲလဲ ဖြစ်ခြင်းဖြင့် ကျေးဇူးပြုခြင်း", "12_Asevanapaccayo.mp3"),
        Condition(13, "ကမ္မပစ္စယော", "Kamma paccayo", "ကံစေတနာဖြင့် ကျေးဇူးပြုခြင်း", "13_Kammapaccayo.mp3"),
        Condition(14, "ဝိပါကပစ္စယော", "Vipāka paccayo", "အကျိုးဝိပါက်အဖြစ် ကျေးဇူးပြုခြင်း", "14_Vipakapaccayo.mp3"),
        Condition(15, "အာဟာရပစ္စယော", "Āhāra paccayo", "အာဟာရအဖြစ် ထောက်ပံ့ခြင်း", "15_Aharapaccayo.mp3"),
        Condition(16, "ဣန္ဒြိယပစ္စယော", "Indriya paccayo", "အစိုးရခြင်းသဘောဖြင့် ကျေးဇူးပြုခြင်း", "16_Indriyapaccayo.mp3"),
        Condition(17, "ဈာနပစ္စယော", "Jhāna paccayo", "ဈာနင်္ဂတရားတို့၏ အစွမ်းဖြင့် ကျေးဇူးပြုခြင်း", "17_Jhanapaccayo.mp3"),
        Condition(18, "မဂ္ဂပစ္စယော", "Magga paccayo", "လမ်းကြောင်းအဖြစ် ကျေးဇူးပြုခြင်း", "18_Maggapaccayo.mp3"),
        Condition(19, "သမ္ပယုတ္တပစ္စယော", "Sampayutta paccayo", "ယှဉ်တွဲဆက်စပ်၍ ကျေးဇူးပြုခြင်း", "19_Sampayuttapaccayo.mp3"),
        Condition(20, "ဝိပ္ပယုတ္တပစ္စယော", "Vippayutta paccayo", "မယှဉ်တွဲဘဲ ကျေးဇူးပြုခြင်း", "20_Vippayuttapaccayo.mp3"),
        Condition(21, "အတ္ထိပစ္စယော", "Atthi paccayo", "ရှိနေခြင်းဖြင့် ကျေးဇူးပြုခြင်း", "21_Atthipaccayo.mp3"),
        Condition(22, "နတ္ထိပစ္စယော", "Natthi paccayo", "မရှိတော့ခြင်းဖြင့် ကျေးဇူးပြုခြင်း", "22_Natthipaccayo.mp3"),
        Condition(23, "ဝိဂတပစ္စယော", "Vigata paccayo", "ကင်းပျောက်ခြင်းဖြင့် ကျေးဇူးပြုခြင်း", "23_Vigatapaccayo.mp3"),
        Condition(24, "အဝိဂတပစ္စယော", "Avigata paccayo", "မကင်းပျောက်သေးခြင်းဖြင့် ကျေးဇူးပြုခြင်း", "24_Avigatapaccayo.mp3"),
    )
}
