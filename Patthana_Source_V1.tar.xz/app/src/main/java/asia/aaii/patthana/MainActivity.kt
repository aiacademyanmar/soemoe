package asia.aaii.patthana

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.BitmapFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Wine = Color(0xFF67272B)
private val Gold = Color(0xFFB9843F)
private val Pale = Color(0xFFFFF8ED)
private val Ink = Color(0xFF332B27)
private val Green = Color(0xFF29594D)
private val White = Color.White

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(103,39,43)
        window.navigationBarColor = android.graphics.Color.rgb(255,248,237)
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent { PatthanaApp() }
    }
}

@Composable
private fun PatthanaApp() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("patthana_prefs", 0) }
    var tab by remember { mutableStateOf("home") }
    var chosen by remember { mutableStateOf<Condition?>(null) }
    var bookPage by remember { mutableIntStateOf(1) }
    var search by remember { mutableStateOf("") }
    var hostBase by remember { mutableStateOf(prefs.getString("licensed_host", "") ?: "") }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var refresh by remember { mutableIntStateOf(0) }
    var lastStatus by remember { mutableStateOf("") }
    var playingId by remember { mutableIntStateOf(-1) }

    val player = remember { ExoPlayer.Builder(ctx).build() }
    var isPlaying by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(value: Boolean) { isPlaying = value }
            override fun onPlaybackStateChanged(state: Int) { duration = player.duration.coerceAtLeast(0L) }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); player.release() }
    }
    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(400L)
        }
    }
    val localPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && chosen != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            catch (_: Exception) {}
            prefs.edit().putString("local_${chosen!!.id}", uri.toString()).apply()
            lastStatus = "MP3 ကို Local Library ထဲ ချိတ်ဆက်ပြီးပါပြီ"
            refresh++
        }
    }
    fun playLink(uri: Uri, id: Int) {
        try {
            player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play()
            playingId = id; tab = "listen"; chosen = null
            lastStatus = "အသံဖွင့်နေပါသည်"
        } catch (ex: Exception) { lastStatus = "အသံဖွင့်၍ မရပါ: ${ex.message ?: "unknown"}" }
    }
    fun external(uri: String) {
        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri))) }
        catch (_: Exception) { lastStatus = "Browser ဖွင့်၍ မရပါ" }
    }
    fun localUri(c: Condition) = prefs.getString("local_${c.id}", null)
    val bg = if (dark) Color(0xFF171C1B) else Pale
    val surface = if (dark) Color(0xFF28302D) else White
    val text = if (dark) Color(0xFFFBECCF) else Ink
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary=Gold,background=bg,surface=surface,onSurface=text)
        else lightColorScheme(primary=Wine,background=bg,surface=surface,onSurface=text)) {
        Column(Modifier.fillMaxSize().background(bg)) {
            Row(Modifier.fillMaxWidth().background(Wine).statusBarsPadding().padding(horizontal=18.dp, vertical=13.dp), verticalAlignment=Alignment.CenterVertically) {
                Text("❁", fontSize=26.sp, color=Gold)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("ပဋ္ဌာန်း အလင်း", fontSize=20.sp, fontWeight=FontWeight.Bold, color=White)
                    Text("PAṬṬHĀNA • မူရင်းကျမ်းလေ့လာရေး", fontSize=10.sp, color=Color(0xFFEED5BC))
                }
                IconButton(onClick={tab="settings"}) { Icon(Icons.Rounded.Settings, null, tint=White) }
            }
            Box(Modifier.weight(1f)) {
                when {
                    chosen != null -> ConditionDetail(chosen!!, surface,text,
                        onBack={chosen=null},
                        isDone=prefs.getBoolean("done_${chosen!!.id}",false),
                        onDone={ val c=chosen!!; prefs.edit().putBoolean("done_${c.id}",!prefs.getBoolean("done_${c.id}",false)).apply();refresh++ },
                        onOriginal={external(chosen!!.sourceUrl)},
                        onPick={localPicker.launch(arrayOf("audio/*","application/octet-stream"))},
                        onLocalPlay={val c=chosen!!; localUri(c)?.let {playLink(Uri.parse(it),c.id)}},
                        onHostedPlay={val c=chosen!!; if(hostBase.startsWith("https://")) playLink(Uri.parse(hostBase.trimEnd('/')+"/"+c.fileName),c.id)},
                        hasLocal=localUri(chosen!!)!=null,
                        hasHost=hostBase.startsWith("https://"))
                    tab=="home" -> HomeScreen(surface,text,
                        doneCount=Catalog.data.count { prefs.getBoolean("done_${it.id}",false) },
                        onExplore={tab="conditions"},onBook={tab="book"},onListen={tab="listen"},
                        onFirst={chosen=Catalog.data[0]})
                    tab=="conditions" -> Column {
                        TextField(value=search,onValueChange={search=it},modifier=Modifier.fillMaxWidth().padding(14.dp),
                            placeholder={Text("ပစ္စည်းအမည် ရှာရန်…")},leadingIcon={Icon(Icons.Rounded.Search,null)},singleLine=true,
                            shape=RoundedCornerShape(18.dp),colors=TextFieldDefaults.colors(focusedIndicatorColor=Color.Transparent,unfocusedIndicatorColor=Color.Transparent))
                        LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(horizontal=14.dp, vertical=6.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                            items(Catalog.data.filter{it.mm.contains(search,true)||it.pali.contains(search,true)}) { c ->
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(surface).clickable{chosen=c}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
                                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Wine),contentAlignment=Alignment.Center){Text("${c.id}",color=White,fontWeight=FontWeight.Bold)}
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)){
                                        Text(c.mm,color=text,fontWeight=FontWeight.Bold,fontSize=17.sp)
                                        Text(c.pali,color=Gold,fontSize=12.sp)
                                        Text(c.meaning,color=text.copy(alpha=.72f),fontSize=12.sp,maxLines=2)
                                    }
                                    Icon(if(prefs.getBoolean("done_${c.id}",false)) Icons.Rounded.CheckCircle else Icons.Rounded.ChevronRight,null,tint=Gold)
                                }
                            }
                        }
                    }
                    tab=="book" -> BookScreen(bookPage,{bookPage=it},surface,text)
                    tab=="listen" -> LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        item { HeaderText("ပဋ္ဌာန်း အသံစာကြည့်တိုက်", "ကိုယ်ပိုင်ခွင့်ပြုထားသောဖိုင် သို့မဟုတ် Local MP3 ကို နားထောင်ပါ",text) }
                        item {
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Wine).padding(16.dp)){
                                Text("♫  Now Listening",color=Color(0xFFEFD3AD),fontSize=12.sp)
                                Text(Catalog.data.getOrNull(playingId-1)?.mm ?: "အသံဖိုင် ရွေးချယ်ပါ",color=White,fontWeight=FontWeight.Bold,fontSize=19.sp)
                                Slider(value=if(duration>0)(position.toFloat()/duration).coerceIn(0f,1f) else 0f,onValueChange={if(duration>0)player.seekTo((it*duration).toLong())},colors=SliderDefaults.colors(thumbColor=Gold,activeTrackColor=Gold))
                                Row(verticalAlignment=Alignment.CenterVertically){
                                    Text("${position/60000}:${(position/1000%60).toString().padStart(2,'0')}",color=White,fontSize=12.sp)
                                    Spacer(Modifier.weight(1f))
                                    IconButton(onClick={if(isPlaying) player.pause() else player.play()}){Icon(if(isPlaying)Icons.Rounded.PauseCircle else Icons.Rounded.PlayCircle,null,tint=White,modifier=Modifier.size(38.dp))}
                                    Spacer(Modifier.weight(1f))
                                    Text("${duration/60000}:${(duration/1000%60).toString().padStart(2,'0')}",color=White,fontSize=12.sp)
                                }
                            }
                        }
                        item { Text("MP3 ဖိုင်များ",fontWeight=FontWeight.Bold,fontSize=19.sp,color=text) }
                        items(Catalog.data) { c ->
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(surface).padding(14.dp)){
                                Text("${c.id.toString().padStart(2,'0')}   ${c.mm}",fontWeight=FontWeight.Bold,color=text)
                                Text(c.pali,color=Gold,fontSize=12.sp)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
                                    SmallAction("မူရင်း ↗",onClick={external(c.sourceUrl)})
                                    if(localUri(c)!=null) SmallAction("Local ▶",onClick={playLink(Uri.parse(localUri(c)!!),c.id)})
                                    else SmallAction("ဖိုင်ရွေး",onClick={chosen=c;localPicker.launch(arrayOf("audio/*","application/octet-stream"))})
                                    if(hostBase.startsWith("https://")) SmallAction("Hosting ▶",onClick={playLink(Uri.parse(hostBase.trimEnd('/')+"/"+c.fileName),c.id)})
                                }
                            }
                        }
                        item { Text("Source: Abhidhamma.com — Audio rights remain with their respective owners. No third-party audio is bundled.",fontSize=11.sp,color=text.copy(alpha=.7f)) }
                    }
                    else -> SettingsScreen(hostBase,{hostBase=it;prefs.edit().putString("licensed_host",it).apply()},dark,{dark=it;prefs.edit().putBoolean("dark",it).apply()},text,surface,onSource={external(Catalog.sourcePage)})
                }
            }
            if(lastStatus.isNotBlank()) {
                Row(Modifier.fillMaxWidth().background(Color(0xFFEBDBBE)).clickable{lastStatus=""}.padding(8.dp),verticalAlignment=Alignment.CenterVertically){
                    Text(lastStatus,color=Wine,fontSize=11.sp,modifier=Modifier.weight(1f)); Text("✕",color=Wine)
                }
            }
            Row(Modifier.fillMaxWidth().background(surface).navigationBarsPadding().padding(vertical=6.dp),horizontalArrangement=Arrangement.SpaceEvenly){
                NavItem("home","ပင်မ",Icons.Rounded.Home,tab){tab="home";chosen=null}
                NavItem("conditions","၂၄ ပစ္စည်း",Icons.Rounded.MenuBook,tab){tab="conditions";chosen=null}
                NavItem("book","စာအုပ်",Icons.Rounded.AutoStories,tab){tab="book";chosen=null}
                NavItem("listen","အသံ",Icons.Rounded.Headphones,tab){tab="listen";chosen=null}
                NavItem("settings","ဆက်တင်",Icons.Rounded.Settings,tab){tab="settings";chosen=null}
            }
        }
    }
}

@Composable private fun NavItem(id:String,label:String,icon:androidx.compose.ui.graphics.vector.ImageVector,tab:String,onClick:()->Unit){
    val active=id==tab
    Column(Modifier.width(72.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick=onClick).padding(vertical=3.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Icon(icon,null,tint=if(active)Wine else Color.Gray)
        Text(label,fontSize=10.sp,color=if(active)Wine else Color.Gray,fontWeight=if(active)FontWeight.Bold else FontWeight.Normal)
    }
}
@Composable private fun HeaderText(title:String,subtitle:String,text:Color){
    Column { Text(title,color=text,fontSize=23.sp,fontWeight=FontWeight.Bold);Text(subtitle,color=text.copy(alpha=.7f),fontSize=12.sp) }
}
@Composable private fun SmallAction(label:String,onClick:()->Unit){
    OutlinedButton(onClick=onClick,contentPadding=PaddingValues(horizontal=8.dp,vertical=2.dp),modifier=Modifier.height(34.dp)){
        Text(label,fontSize=11.sp,maxLines=1)
    }
}
@Composable private fun HomeScreen(surface:Color,text:Color,doneCount:Int,onExplore:()->Unit,onBook:()->Unit,onListen:()->Unit,onFirst:()->Unit){
    LazyColumn(contentPadding=PaddingValues(17.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(25.dp)).background(Brush.linearGradient(listOf(Wine,Color(0xFF91513C)))).padding(22.dp)){
                Text("✺  သဒ္ဓါ • ပညာ • ဓမ္မ",color=Color(0xFFFFD79B),fontSize=12.sp)
                Spacer(Modifier.height(15.dp))
                Text("ပဋ္ဌာန်းကျမ်း\nရွတ်ဖတ်လေ့လာရေး",color=White,fontSize=27.sp,fontWeight=FontWeight.Bold,lineHeight=40.sp)
                Spacer(Modifier.height(8.dp))
                Text("ပစ္စည်း ၂၄ ပါး • ပါဠိနှင့်မြန်မာအဓိပ္ပာယ်",color=Color(0xFFFFE2C5),fontSize=13.sp)
                Spacer(Modifier.height(18.dp))
                Button(onClick=onExplore,colors=ButtonDefaults.buttonColors(containerColor=Gold)){Text("စတင်လေ့လာရန်  →",color=White)}
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){
                StatCard("၂၄", "ပစ္စည်း",surface,text,Modifier.weight(1f))
                StatCard("၄၀", "A5 စာမျက်နှာ",surface,text,Modifier.weight(1f))
                StatCard("$doneCount/24", "လေ့လာပြီး",surface,text,Modifier.weight(1f))
            }
        }
        item { HeaderText("လေ့လာရေး မီနူး", "ရုပ်ပုံ၊ အသံ၊ ကျမ်းစာတို့ကို အတူတကွ လေ့လာနိုင်သည်",text) }
        item { ActionCard("01", "ပစ္စည်း ၂၄ ပါး", "ပါဠိ • အဓိပ္ပာယ် • မှတ်သားရန်",Icons.Rounded.Spa,surface,text,onExplore) }
        item { ActionCard("02", "A5 ရုပ်ပုံပါ စာအုပ်", "စာမျက်နှာ ၄၀ • Offline Book",Icons.Rounded.AutoStories,surface,text,onBook) }
        item { ActionCard("03", "အသံစာကြည့်တိုက်", "မူရင်းအရင်းအမြစ် • Local MP3",Icons.Rounded.Headphones,surface,text,onListen) }
        item { ActionCard("04", "ယနေ့လေ့လာရန်", "ဟေတုပစ္စယောမှ စတင်ရန်",Icons.Rounded.PlayCircle,surface,text,onFirst) }
        item { Text("အဘိဓမ္မာ ကျမ်းစာလေ့လာရေးအတွက် သင်ကြားရေးမူကြမ်းဖြစ်ပြီး ရွတ်ဖတ်သံစဉ်များကို မူရင်းဆရာတော်အသံဖြင့် စစ်ဆေးသင့်သည်။",fontSize=12.sp,color=text.copy(alpha=.65f)) }
    }
}
@Composable private fun StatCard(value:String,label:String,bg:Color,text:Color,modifier:Modifier){
    Column(modifier.clip(RoundedCornerShape(17.dp)).background(bg).padding(11.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Text(value,color=Wine,fontWeight=FontWeight.Bold,fontSize=22.sp);Text(label,color=text,fontSize=10.sp)
    }
}
@Composable private fun ActionCard(num:String,title:String,subtitle:String,icon:androidx.compose.ui.graphics.vector.ImageVector,bg:Color,text:Color,onClick:()->Unit){
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(bg).clickable(onClick=onClick).padding(18.dp),verticalAlignment=Alignment.CenterVertically){
        Box(Modifier.size(50.dp).clip(CircleShape).background(Color(0xFFF5E6CE)),contentAlignment=Alignment.Center){Icon(icon,null,tint=Wine,modifier=Modifier.size(27.dp))}
        Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Text(title,color=text,fontWeight=FontWeight.Bold);Text(subtitle,color=text.copy(alpha=.65f),fontSize=11.sp)}
        Icon(Icons.Rounded.ChevronRight,null,tint=Gold)
    }
}
@Composable private fun ConditionDetail(c:Condition,surface:Color,text:Color,onBack:()->Unit,isDone:Boolean,onDone:()->Unit,onOriginal:()->Unit,onPick:()->Unit,onLocalPlay:()->Unit,onHostedPlay:()->Unit,hasLocal:Boolean,hasHost:Boolean){
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
        item { TextButton(onClick=onBack){Icon(Icons.Rounded.ArrowBack,null); Text("ပစ္စည်းစာရင်းသို့") } }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp)).background(Brush.verticalGradient(listOf(Wine,Color(0xFF8F5044)))).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){
                Text("ပစ္စည်း ${c.id} / ၂၄",color=Color(0xFFEBC495),fontSize=13.sp)
                Spacer(Modifier.height(17.dp));Text("❁",color=Color(0xFFFFD79B),fontSize=53.sp)
                Text(c.mm,color=White,fontSize=26.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center)
                Text(c.pali,color=Color(0xFFFFE6BD),fontSize=15.sp)
            }
        }
        item { DetailBox("မြန်မာအဓိပ္ပာယ်",c.meaning,surface,text) }
        item { DetailBox("စာဖတ်နည်း", "ပါဠိအမည်ကို အမှန်အကန် ထုတ်ဖတ်ပြီး အဓိပ္ပာယ်ကို ချိန်ဆ၍ နားလည်ပါ။ အကျယ်ပါဠိစာသားအတွက် မူရင်းကျမ်းကို အဓိကထားပါ။",surface,text) }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(surface).padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
                Text("🎧  အသံဖြင့် လေ့လာရန်",fontWeight=FontWeight.Bold,color=text,fontSize=18.sp)
                Text("မူရင်း MP3 ကို Browser ဖြင့် နားထောင်ရန် — ခွင့်ပြုချက်မရှိဘဲ အသံဖိုင်ကို APK အတွင်း မထည့်ထားပါ။",fontSize=12.sp,color=text.copy(alpha=.72f))
                Button(onClick=onOriginal,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Wine)){Text("မူရင်းအသံ ဖွင့်ရန် ↗")}
                OutlinedButton(onClick=if(hasLocal) onLocalPlay else onPick,modifier=Modifier.fillMaxWidth()){
                    Text(if(hasLocal)"Local MP3 နားထောင်ရန် ▶" else "မိမိ MP3 ဖိုင် ချိတ်ဆက်ရန်")
                }
                if(hasHost) OutlinedButton(onClick=onHostedPlay,modifier=Modifier.fillMaxWidth()){Text("Licensed Hosting MP3 ဖွင့်ရန် ▶")}
            }
        }
        item {
            Button(onClick=onDone,modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=if(isDone)Green else Gold)){
                Icon(if(isDone) Icons.Rounded.CheckCircle else Icons.Rounded.Done,null); Spacer(Modifier.width(8.dp));Text(if(isDone)"လေ့လာပြီး ✓" else "လေ့လာပြီးကြောင်း မှတ်သားရန်")
            }
        }
    }
}
@Composable private fun DetailBox(title:String,content:String,surface:Color,text:Color){
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(surface).padding(16.dp)){
        Text(title,color=Gold,fontWeight=FontWeight.Bold,fontSize=14.sp);Spacer(Modifier.height(7.dp));Text(content,color=text,fontSize=17.sp,lineHeight=27.sp)
    }
}
@Composable private fun BookScreen(page:Int,onPage:(Int)->Unit,surface:Color,text:Color){
    val ctx= LocalContext.current
    val image = remember(page) { try {
        ctx.assets.open("book/page_${page.toString().padStart(2,'0')}.webp").use { BitmapFactory.decodeStream(it)?.asImageBitmap() }
    } catch (_:Exception) { null } }
    Column(Modifier.fillMaxSize().padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)){
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
            Column(Modifier.weight(1f)){Text("ပဋ္ဌာန်း A5 လက်စွဲစာအုပ်",fontSize=19.sp,fontWeight=FontWeight.Bold,color=text);Text("Offline • စာမျက်နှာ $page / 40",fontSize=12.sp,color=Gold)}
            Icon(Icons.Rounded.AutoStories,null,tint=Wine)
        }
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(surface),contentAlignment=Alignment.Center){
            if(image!=null) Image(image,null,modifier=Modifier.fillMaxSize(),contentScale=ContentScale.Fit)
            else Text("စာမျက်နှာ မရှိပါ",color=text)
        }
        Slider(value=page.toFloat(),onValueChange={onPage(it.toInt().coerceIn(1,40))},valueRange=1f..40f,steps=38)
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){
            OutlinedButton(onClick={onPage((page-1).coerceAtLeast(1))},enabled=page>1){Icon(Icons.Rounded.ChevronLeft,null);Text("နောက်ပြန်")}
            Button(onClick={onPage((page+1).coerceAtMost(40))},enabled=page<40){Text("နောက်စာမျက်နှာ");Icon(Icons.Rounded.ChevronRight,null)}
        }
    }
}
@Composable private fun SettingsScreen(base:String,onBase:(String)->Unit,dark:Boolean,onDark:(Boolean)->Unit,text:Color,surface:Color,onSource:()->Unit){
    LazyColumn(contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(18.dp)){
        item { HeaderText("ဆက်တင်နှင့် အသံမူရင်း", "Audio source & offline library settings",text) }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(surface).padding(16.dp)){
                Text("🎵 ကိုယ်ပိုင် Hosting URL",fontWeight=FontWeight.Bold,color=text)
                Text("မူပိုင်ခွင့်/ပြန်လည်ဖြန့်ချိခွင့် ရရှိထားသည့် MP3 ဖိုင်များအတွက်သာ",fontSize=12.sp,color=text.copy(alpha=.7f))
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value=base,onValueChange=onBase,modifier=Modifier.fillMaxWidth(),singleLine=true,
                    label={Text("https://your-domain.com/patthana/audio")},isError=base.isNotEmpty()&&!base.startsWith("https://"))
                Text("မူရင်းအမည်အတိုင်း MP3 များထားပြီးမှ Hosting Play ကို နှိပ်နိုင်သည်။",fontSize=11.sp,color=text.copy(alpha=.7f))
            }
        }
        item { Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).background(surface).padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text("Dark Reading Mode",color=text,modifier=Modifier.weight(1f));Switch(checked=dark,onCheckedChange=onDark)} }
        item { DetailBox("မူရင်းအရင်းအမြစ်", "Abhidhamma.com – Sayadaw Dr. Nandamālābhivaṃsa (Malaysia 2007–2008). အသံဖိုင်များကို မူရင်းအခွင့်အရေးပိုင်ရှင်ထံမှ ခွင့်ပြုချက်ရမှ ကိုယ်ပိုင် Server နှင့် App အတွင်း ပြန်လည်ဖြန့်ချိရန်။",surface,text) }
        item { Button(onClick=onSource,modifier=Modifier.fillMaxWidth()){Text("မူရင်း Website ကြည့်ရန် ↗") } }
        item { Text("Version 1.0 • Native Jetpack Compose • 40-page offline reader • Local MP3 player",fontSize=11.sp,color=text.copy(alpha=.7f)) }
    }
}
